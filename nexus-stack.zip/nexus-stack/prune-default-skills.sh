#!/usr/bin/env bash
# Remove as skills padrão do Nexus para a biblioteca ficar só com as nossas.
# KEEP_BUNDLED_SKILLS: lista (separada por vírgula) de skills padrão a manter. Ex.: "paperclip"
set -euo pipefail

SKILLS_DIR=/app/skills
SERVICE=/app/server/src/services/company-skills.ts
KEEP=",${KEEP_BUNDLED_SKILLS:-},"

for dir in "$SKILLS_DIR"/*/; do
  [ -d "$dir" ] || continue
  name=$(basename "$dir")
  if [[ "$KEEP" != *",$name,"* ]]; then
    rm -rf "$dir"
    echo "[prune-skills] removida: $name"
  fi
done

# first-task é injetada pelo código do servidor, não pela pasta de skills
if [[ "$KEEP" != *",first-task,"* ]] && grep -q "firstTaskSkill\], db" "$SERVICE"; then
  sed -i 's/\[\.\.\.bundledSkills, firstTaskSkill\]/[...bundledSkills]/; s/upsertImportedSkills(companyId, \[firstTaskSkill\]/upsertImportedSkills(companyId, []/' "$SERVICE"
  echo "[prune-skills] removida: first-task"
fi
