---
schema: agentcompanies/v1
kind: company
slug: org-de-teste
name: Org de Teste
description: Organização de teste com vários agentes para validar o Nexus
version: 0.1.0
goals:
  - Validar o fluxo de agentes, tarefas e tools no Nexus
---

Organização de teste: o Nexus coordena um engenheiro, um pesquisador e um revisor.
