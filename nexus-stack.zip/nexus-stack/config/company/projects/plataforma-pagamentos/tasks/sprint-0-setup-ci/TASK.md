---
name: Sprint 0 - Setup de CI/CD
assignee: devops
project: plataforma-pagamentos
---

Monte o pipeline de CI (build, testes, lint) e descreva o fluxo de deploy para os ambientes de homologação e produção.
