---
name: Definir backlog inicial
assignee: product-owner
project: plataforma-pagamentos
---

Escreva as 5 primeiras histórias de usuário da plataforma de pagamentos, com critérios de aceite, e priorize por valor.
