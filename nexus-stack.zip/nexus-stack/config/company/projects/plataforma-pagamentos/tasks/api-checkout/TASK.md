---
name: API de checkout
assignee: dev-backend
project: plataforma-pagamentos
---

Implemente o endpoint de criação de pagamento (`POST /payments`) com validação, testes e documentação. Siga a definição de pronto.
