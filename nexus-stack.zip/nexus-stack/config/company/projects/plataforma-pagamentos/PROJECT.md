---
name: Plataforma de Pagamentos
slug: plataforma-pagamentos
description: API de pagamentos com checkout, conciliação e pipeline de entrega contínua
owner: tech-lead
---

Projeto de backend e infraestrutura. Entregas em sprints de 2 semanas.
