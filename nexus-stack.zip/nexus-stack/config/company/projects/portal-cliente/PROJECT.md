---
name: Portal do Cliente
slug: portal-cliente
description: Portal web para clientes acompanharem pedidos e pagamentos
owner: product-owner
---

Projeto de frontend, integrado à Plataforma de Pagamentos. Entregas em sprints de 2 semanas.
