---
name: Refinar histórias do portal
assignee: product-owner
project: portal-cliente
---

Refine com o time as histórias de login e listagem de pedidos: critérios de aceite e estimativa.
