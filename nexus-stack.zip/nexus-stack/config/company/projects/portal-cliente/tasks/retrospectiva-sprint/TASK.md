---
name: Retrospectiva da sprint
assignee: scrum-master
project: portal-cliente
recurring: true
---

Conduza a retrospectiva ao fim de cada sprint: o que foi bem, o que melhorar e ações com responsável.
