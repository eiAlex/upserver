---
name: Daily standup
assignee: scrum-master
project: portal-cliente
recurring: true
---

Use a skill `daily-standup` para consolidar o status do time e destacar impedimentos.
