const net = require("net");

const listenPort = Number(process.env.PROXY_PORT || 3100);
const targetPort = Number(process.env.PORT || 3101);

net
  .createServer((client) => {
    const upstream = net.connect(targetPort, "127.0.0.1");
    client.pipe(upstream).pipe(client);
    client.on("error", () => upstream.destroy());
    upstream.on("error", () => client.destroy());
  })
  .listen(listenPort, "0.0.0.0");
