---
name: sprint-planning
description: Conduz o planejamento de sprint: define meta, seleciona histórias do backlog conforme a capacidade e quebra em tarefas.
---

# Sprint Planning

1. Defina a **meta da sprint** em uma frase.
2. Pegue do topo do backlog as histórias priorizadas pelo Product Owner até a capacidade do time (sprint de 2 semanas).
3. Cada história deve ter critérios de aceite e estimativa (pontos). Sem isso, devolva para refinamento.
4. Quebre as histórias em tarefas técnicas e atribua aos desenvolvedores.
5. Registre o resultado como comentário na issue da sprint: meta, histórias, riscos.
