---
name: hello-tool
description: Tool de teste. Use para validar que os agentes conseguem executar scripts do Nexus; devolve uma saudação e a data/hora do pod.
---

# hello-tool

Execute:

```bash
bash scripts/hello.sh "<nome>"
```

Saída esperada: `Olá, <nome>! Tool executada em <hostname> às <UTC>`.
