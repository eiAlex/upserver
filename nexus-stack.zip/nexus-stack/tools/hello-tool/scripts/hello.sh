#!/usr/bin/env bash
echo "Olá, ${1:-mundo}! Tool executada em $(hostname) às $(date -u +%FT%TZ)"
