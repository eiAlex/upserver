---
name: daily-standup
description: Gera o resumo do daily: o que foi feito, o que será feito e impedimentos de cada agente.
---

# Daily Standup

Para cada agente do time, colete em no máximo 3 linhas:

- **Ontem:** o que foi concluído
- **Hoje:** o que será feito
- **Impedimentos:** o que bloqueia (ou "nenhum")

Publique o consolidado como comentário e sinalize impedimentos ao Scrum Master.
