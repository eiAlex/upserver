---
name: definition-of-done
description: Definição de Pronto (DoD) do time; use antes de mover uma história para concluída.
---

# Definition of Done

Uma história só está pronta quando:

- [ ] Código revisado e aprovado (skill `code-review`)
- [ ] Testes automatizados passando
- [ ] Critérios de aceite validados pelo QA
- [ ] Pipeline de CI verde
- [ ] Documentação atualizada, se aplicável
- [ ] Product Owner aceitou a entrega
