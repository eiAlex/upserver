---
name: code-review
description: Checklist de revisão de código para o Tech Lead e desenvolvedores.
---

# Code Review

Verifique, nesta ordem:

1. Atende aos critérios de aceite da história?
2. Testes cobrindo o comportamento novo e casos de borda?
3. Segurança: validação de entrada, segredos fora do código, autorização.
4. Legibilidade e consistência com o restante da base.
5. Sem mudanças fora do escopo.

Responda com **Aprovado** ou **Ajustes necessários** e uma lista objetiva.
