// Rebranding "Paperclip" -> "Nexus" na UI (texto visível, título, manifest, ícones).
// Roda no estágio builder, antes de `pnpm build`. Não altera identificadores,
// pacotes, variáveis PAPERCLIP_* nem chaves de storage (apenas "Paperclip" capitalizado).
const fs = require("fs");
const path = require("path");

const BRAND = process.env.BRAND_NAME || "Nexus";
const root = "/app/ui";

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else out.push(p);
  }
  return out;
}

let changed = 0;
function rewrite(file, fn) {
  const before = fs.readFileSync(file, "utf8");
  const after = fn(before);
  if (after !== before) {
    fs.writeFileSync(file, after);
    changed++;
  }
}

// O ícone de clipe do lucide vira um ícone de rede (Network), mantendo o identificador local.
const W = "(?<![A-Za-z])Paperclip(?![A-Za-z])";
const ICON_USE = new RegExp(`(<Paperclip(?![A-Za-z])|icon:\\s*Paperclip(?![A-Za-z])|=\\s*Paperclip(?![A-Za-z])|typeof Paperclip(?![A-Za-z]))`, "g");

function patchSource(src) {
  const imports = [];
  src = src.replace(/import\s*\{[^}]*\}\s*from\s*["']lucide-react["'];?/g, (m) => {
    imports.push(m.replace(new RegExp(W), "Network as Paperclip"));
    return `\u0001IMP${imports.length - 1}\u0001`;
  });
  src = src
    .split("\n")
    .map((line) =>
      line
        .replace(ICON_USE, (m) => m.replace("Paperclip", "\u0000ICON\u0000"))
        .replace(new RegExp(W, "g"), BRAND)
        .replace(/\u0000ICON\u0000/g, "Paperclip"),
    )
    .join("\n");
  return src.replace(/\u0001IMP(\d+)\u0001/g, (_, i) => imports[Number(i)]);
}
for (const f of walk(path.join(root, "src"))) {
  if (!/\.(tsx?|css)$/.test(f) || /\.(test|stories)\./.test(f)) continue;
  rewrite(f, patchSource);
}

for (const f of ["index.html", "public/site.webmanifest", "public/sw.js"]) {
  rewrite(path.join(root, f), (s) => s.replace(new RegExp(W, "g"), BRAND));
}

const brandDir = "/tmp/brand";
for (const f of fs.readdirSync(brandDir)) {
  fs.copyFileSync(path.join(brandDir, f), path.join(root, "public", f));
}

console.log(`[brand] ${changed} arquivos reescritos para "${BRAND}"`);
