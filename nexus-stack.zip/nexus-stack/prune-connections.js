#!/usr/bin/env node
// Mantém só as conexões (app definitions) permitidas no catálogo do Nexus.
// KEEP_CONNECTIONS: slugs separados por vírgula (sobrescreve o padrão).
const fs = require("fs");

const DEFAULT_KEEP =
  "bedrock,anthropic,github,local,messages-api,openai,responses-api";
const keep = new Set(
  (process.env.KEEP_CONNECTIONS || DEFAULT_KEEP)
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),
);

const file = "/app/packages/shared/src/app-definitions.generated.ts";
const src = fs.readFileSync(file, "utf8");

const imports = [...src.matchAll(/^import (a\d+) from "\.\/app-definitions\/([^"]+)\.json".*$/gm)];
if (imports.length === 0) {
  console.error("[prune-connections] formato inesperado de app-definitions.generated.ts; nada foi alterado");
  process.exit(0);
}

const kept = imports.filter((m) => keep.has(m[2]));
const keptNames = new Set(kept.map((m) => m[1]));
const missing = [...keep].filter((s) => !imports.some((m) => m[2] === s));
if (missing.length) console.error(`[prune-connections] slugs não encontrados: ${missing.join(", ")}`);

let out = src
  .split("\n")
  .filter((line) => {
    const m = line.match(/^import (a\d+) from "\.\/app-definitions\//);
    return !m || keptNames.has(m[1]);
  })
  .join("\n");

out = out.replace(/export const APP_DEFINITIONS\s*=\s*\[[^\]]*\]/, `export const APP_DEFINITIONS=[${[...keptNames].join(",")}]`);

if (!out.includes(`APP_DEFINITIONS=[${[...keptNames].join(",")}]`)) {
  console.error("[prune-connections] não consegui reescrever APP_DEFINITIONS; nada foi alterado");
  process.exit(0);
}

fs.writeFileSync(file, out);
console.log(`[prune-connections] mantidas ${kept.length}: ${kept.map((m) => m[2]).join(", ")}`);

// Apps de chat nativos (AgentMail, Slack, ...) são fixos na UI; ocultamos todos.
const browse = "/app/ui/src/pages/apps/Browse.tsx";
let browseSrc = fs.readFileSync(browse, "utf8");
const patches = [
  [
    "for (const item of nativeChatApps.filter(item => chatProviderVisible(item.slug, chatConnectorsEnabled, githubEnabled))) {",
    "for (const item of nativeChatApps.filter(() => false)) {",
    "apps de chat nativos",
  ],
  [
    "const aggregatorRows: ConnectorRowModel[] = managedCatalog.filter((app) =>",
    "const aggregatorRows: ConnectorRowModel[] = managedCatalog.filter(() => false).filter((app) =>",
    "apps de agregadores",
  ],
];
for (const [needle, replacement, label] of patches) {
  if (browseSrc.includes(needle)) {
    browseSrc = browseSrc.replace(needle, replacement);
    console.log(`[prune-connections] ocultados: ${label}`);
  } else if (!browseSrc.includes(replacement)) {
    console.error(`[prune-connections] trecho não encontrado em Browse.tsx: ${label}`);
  }
}
fs.writeFileSync(browse, browseSrc);

// Esta constante de módulo quebra a UI inteira quando agentmail não está no catálogo.
const agentMailField = "/app/ui/src/features/connections/AgentMailApiKeyField.tsx";
const unsafe = 'getAppStoreDefinition("agentmail")!.methods[0]!.consoleLinks!.keys!';
const amSrc = fs.readFileSync(agentMailField, "utf8");
if (amSrc.includes(unsafe)) {
  fs.writeFileSync(agentMailField, amSrc.replace(unsafe, 'getAppStoreDefinition("agentmail")?.methods[0]?.consoleLinks?.keys ?? ""'));
  console.log("[prune-connections] AgentMailApiKeyField protegido");
}
