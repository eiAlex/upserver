#!/usr/bin/env bash
set -euo pipefail

cd /app
MARKER="$PAPERCLIP_HOME/.company-seeded"

/opt/nexus/prune-default-skills.sh

pnpm --filter @paperclipai/server dev &
SERVER_PID=$!
node /opt/nexus/proxy.js &
trap 'kill $SERVER_PID 2>/dev/null || true' TERM INT

# Espera a API subir
for i in $(seq 1 120); do
  if node -e "fetch('$PAPERCLIP_API_URL/api/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))"; then
    break
  fi
  sleep 2
done

# Importa a organização de teste uma única vez (sem DB externo, estado fica em $PAPERCLIP_HOME)
if [ ! -f "$MARKER" ]; then
  if pnpm paperclipai company import "$COMPANY_DIR" \
      --target new --new-company-name "$COMPANY_NAME" --include company,agents,projects,tasks,skills --yes; then
    touch "$MARKER"
  else
    echo "WARN: import da empresa falhou; rode manualmente: pnpm paperclipai company import $COMPANY_DIR --target new" >&2
  fi
fi

wait $SERVER_PID
